import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import emailjs, { EmailJSResponseStatus } from 'emailjs-com';
import { UserMgmtService } from '../service/user-mgmt.service';

import { IDropdownSettings } from 'ng-multiselect-dropdown';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent {

  @ViewChild('cardBody', {static: true}) cardBody: ElementRef | undefined;
  filterSearchTerm='';
  filterArray?: Array<{'id':number, 'label':string}>;

  name = "V";

  onSearch() {

    if(this.filterSearchTerm.length) {
      this.filterArray = this.dropdownList.filter(item=>{
        console.log(item)
        return item.label.toLowerCase().includes(this.filterSearchTerm.toLowerCase());
      })
    } else {
      this.filterArray = this.dropdownList;
    }
  }

  isShown: boolean = false;
  showFilter: boolean = true;

  toggleIsShown() {
    this.isShown = !this.isShown;
  }

  dropdownList = [
    {'id': 1, 'label': 'Messi'},
    {'id': 2, 'label': 'Ronaldo'},
    {'id': 3, 'label': 'Sakkhuu'},
    {'id': 4, 'label': 'Gogi'},
    {'id': 5, 'label': 'Lakkhaa'},
    {'id': 6, 'label': 'Lakkri'}
  ];
  selectedItems = [];
  dropdownSettings: IDropdownSettings = {};


  ngOnInit() {
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'label',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: true
    };
    this.filterArray = this.dropdownList;
  }

  registrationform = new FormGroup({
    firstname: new FormControl('', [Validators.required, Validators.pattern('[A-Za-z]+')]),
    lastname: new FormControl('', [Validators.required, Validators.pattern('[A-Za-z]+')]),
    age: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')]),
    gender: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    phone: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
    plan: new FormControl('', Validators.required)
  })


  constructor(private userService: UserMgmtService) {
    this.userService.printSome(); 
   }

  onRegister() {
    console.log(this.registrationform)
    this.userService.addMember(this.registrationform.value)
      .then(() => {
        alert('Member Added Successfully')
        this.sendEmail()

        this.registrationform.reset()
      })
  }

  public sendEmail() {
    // e.preventDefault();
    emailjs.send('registration_service', 'template_6ngqvlm',
      {
        firstname: this.registrationform.value.firstname,
        email: this.registrationform.value.email,
        phone: this.registrationform.value.phone
      }, 'user_mtPx6kjp6pkNpUTeh0MFz')
      .then((result: EmailJSResponseStatus) => {
        console.log(result.text);
      }, (error) => {
        console.log(error.text);
      });
  }

  element?: HTMLElement | null;
  element2?: HTMLElement | null;
  card_body?: HTMLElement | null;

    // clickOutside(elem: any){
    //   console.log(typeof(elem))
    //   this.element = document.getElementById('dropdown1')
    //   this.element2 = document.getElementById('dropdown2')
    //   this.card_body = document.getElementById('cardBody1')
    //   console.log("ELEM----------")
    //   console.log(elem)
    //   console.log("CARDBODY----------")
    //   console.log(this.card_body);
    //   console.log("ELEMENt----------")
    //   console.log(this.element);
    //   if(elem.target != this.element && elem.parent != this.element2){
    //     this.isShown = false;
    //   }

    // }
}
