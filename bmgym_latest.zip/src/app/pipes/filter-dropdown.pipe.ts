import {Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'filterDropdown'
})
export class FilterDropdownPipe implements PipeTransform {
    transform(value: any, ...args: any[]): any{
        console.log("_________________IN PIPE________________");
        let filterString: string = args[0];
        if(value.length === 0 || filterString === '') {
            return value;
        }

        let items:any = [];

        value.forEach((item:any) => {
            if(item.label.toLowerCase().includes(filterString.toLowerCase())) { items.push(item); }
        });

        return items;
    }
}