// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase : {
  apiKey: "AIzaSyB1U-wGTYzQlWKL96Ybxs8o0xem-R5v1pU",
  authDomain: "blackmonster71021.firebaseapp.com",
  projectId: "blackmonster71021",
  storageBucket: "blackmonster71021.appspot.com",
  messagingSenderId: "639507070776",
  appId: "1:639507070776:web:077f19304fc0eef63b4bcd",
  measurementId: "G-GP93HH2CTT"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
